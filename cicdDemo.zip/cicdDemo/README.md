# cicdDemo 

by default all jobs run in parallel